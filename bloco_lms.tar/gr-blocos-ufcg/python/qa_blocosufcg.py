#!/usr/bin/env python
#
# Copyright 2004,2007 Free Software Foundation, Inc.
# 
# This file is part of GNU Radio
# 
# GNU Radio is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# GNU Radio is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with GNU Radio; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

from gnuradio import gr, gr_unittest
import blocosufcg
import math

class qa_blocosufcg (gr_unittest.TestCase):

    def setUp (self):
        self.tb = gr.top_block ()

    def tearDown (self):
        self.tb = None

    def test_001_blocoteste_cc (self):
        src_data = (0.2617968878 + 0j, 0.4363281463 + 0j, 0.61085940487 + 0j, 0.7853906634 + 0j, 1.0471875512 + 0j)
        expected_result = (0.687247 + 0.726424j, 0.240714 + 0.970596j, -0.229094 + 0.973404j, -0.6057 + 0.795693j, -0.912724 + 0.408576j)
        src = gr.vector_source_c (src_data)
        sqr = blocosufcg.blocoteste_cc ()
        dst = gr.vector_sink_c ()
        self.tb.connect (src, sqr)
        self.tb.connect (sqr, dst)
        self.tb.run ()
        result_data = dst.data ()
        self.assertFloatTuplesAlmostEqual (expected_result, result_data, 6)

    def test_002_bloco2_ff (self):
        src_data = (-3, 4, -5.5, 2, 3)
        expected_result = (-6, 8, -11, 4, 6)
        src = gr.vector_source_f (src_data)
        sqr = blocosufcg.bloco2_ff ()
        dst = gr.vector_sink_f ()
        self.tb.connect (src, sqr)
        self.tb.connect (sqr, dst)
        self.tb.run ()
        result_data = dst.data ()
        self.assertFloatTuplesAlmostEqual (expected_result, result_data, 6)
        
if __name__ == '__main__':
    gr_unittest.main ().2617968
